<?php


class CoordinadorClinico
{

}