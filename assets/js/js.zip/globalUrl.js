const GLOBAL_URL = 'http://localhost/clinica_soft';

